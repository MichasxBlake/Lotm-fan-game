extends Node

signal block_vanished

# Called when the node enters the scene tree for the first time.
func loop(number : int, button : int):
	GlobalData.passion += 50

func action(number, button, max_val, current, inside_number, place):
	if current >= max_val:
		var new_but = instance_from_id(button) as ProgressBar
		if new_but:
			new_but.hide()
		
		block_vanished.emit() # Krzyczymy: "Zniknąłem!"
		print("Blok ukryty, sygnał wysłany")
	if place == "House" :
		var place_find = get_node("../../%House")
		var command = place_find.get_child(number+1)
		command.show_new_lore(inside_number)
