extends ColorRect
class_name Lore_Slide

@export var text: String
@export var label : Label
@export var color_rect: ColorRect
@export var bedroom: HBoxContainer

var clicked = false
var current_size : Vector2

# Funkcja pomocnicza, która liczy widoczne dzieci i ustawia rozmiar
func _ready() -> void:
	refresh_ui()



func refresh_ui() -> void:
	var visible_count = 0
	for node in bedroom.get_children():
		if node.is_visible_in_tree():
			visible_count += 1
	
	var new_width = 60 + (190 * max(0, visible_count - 1))
	color_rect.custom_minimum_size = Vector2(new_width, 80)
	current_size = color_rect.custom_minimum_size

func _on_button_button_down() -> void:
	clicked = !clicked # Przełącza true/false
	
	if clicked:
		bedroom.hide()
		color_rect.custom_minimum_size = Vector2(30, 80)
	else:
		bedroom.show()
		# Przywracamy zapamiętany rozmiar
		color_rect.custom_minimum_size = Vector2(current_size.x, 80)

func show_new_lore(inside_number : int):
	var node = bedroom.get_node_or_null(str(inside_number))
	if node:
		node.show()
		# Po pokazaniu nowego elementu, odświeżamy layout raz
		refresh_ui()
		print("Pokazano element: ", inside_number)
